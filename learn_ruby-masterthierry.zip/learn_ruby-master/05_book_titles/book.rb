class Book
# write your code here
end
