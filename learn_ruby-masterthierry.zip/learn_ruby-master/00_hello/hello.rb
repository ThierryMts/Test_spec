#write your code here

def hello
	"Hello!"
end

def greet(who)
	"Hello, #{who}!"
end