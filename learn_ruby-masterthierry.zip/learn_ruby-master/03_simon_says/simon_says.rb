#write your code here
def echo(hello)
	return hello
end

def shout(hello)
	return hello.upcase
end 

def repeat(hello, p)
	return "hello" * p

end

def start_of_word
	return string.split[0]
end

def first_two_letter
	return string.spli[1]
end

def 
